package com.toomda.parasitusfixcore.mixin;

import com.toomda.parasitusfixcore.ParasitusFix;
import net.minecraft.world.biome.Biome;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import techguns.world.StructureLandType;
import techguns.world.StructureSize;
import techguns.world.TGStructureSpawnRegister;
import techguns.world.structures.AircraftCarrier;
import techguns.world.structures.WorldgenStructure;

import java.util.Random;

@Mixin(TGStructureSpawnRegister.class)
public abstract class MixinTGStructureSpawnRegister {
    private static final int RARITY_DIVISOR = 5;

    @Inject(method = "choseStructure", at = @At("RETURN"), cancellable = true, remap = false)
    private static void parasitusfix$rarifyCarrier(Random rnd, Biome biome, StructureSize size,
                                                   StructureLandType type, int dimension,
                                                   CallbackInfoReturnable<WorldgenStructure> cir) {
        Logger logger = ParasitusFix.getLogger();
        WorldgenStructure picked = cir.getReturnValue();
        logger.info("structure to spawn is: " + picked.toString());
        if (picked instanceof AircraftCarrier) {
            logger.info("Structure is AircraftCarrier");
            if (rnd.nextInt(RARITY_DIVISOR) != 0) {
                logger.info("Spawning it!");
                cir.setReturnValue(null);
            }else {
                logger.info("Do not spawn it!");
            }
        }
    }
}
